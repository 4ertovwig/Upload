﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Search_Demo
{
    /// <summary>
    /// 
    /// If run exe-file then exceptions are hasn't
    /// </summary>
    public partial class Form1 : Form
    {
        Int32 i = 0;
        CancellationTokenSource cts;
        
        #region Constructor
        public Form1()
        {
            InitializeComponent();
            ParseText.Enabled = false;
            MainTabControl.TabPages[0].Text = "параметры";
            MainTabControl.TabPages[1].Text = "результат";
            
            FileDir.Text = Properties.Settings.Default.FileDir;
            FileName.Text = Properties.Settings.Default.FileName;
            ParseText.Text = Properties.Settings.Default.ParseText;

            Folder.Click += (sender, e) =>
            {
                if (FoldDialog.ShowDialog() == DialogResult.OK)
                {
                    FileDir.Text = FoldDialog.SelectedPath;
                }
            };
            Stop.Click += (sender, e) =>
            {
                GC.Collect();
                try
                {
                    cts.Cancel();
                }
                catch (System.NullReferenceException)
                { MessageBox.Show("Сначала запустите поиск"); }
            };
            JustText.CheckedChanged += (sender, e) =>
            {
                if ((sender as CheckBox).Checked)
                {
                    ParseText.Enabled = true;
                }
                else
                    ParseText.Enabled = false;
            }; 
        }
        #endregion

        #region FindDirectory
        public void FindDirectory(DirectoryInfo dir, string pattern, CancellationToken cancellationToken)
        {
            try
            {
                //    cancellationToken.ThrowIfCancellationRequested();
                foreach (FileInfo file in dir.GetFiles(pattern))
                {
                    Files.Invoke((Action)(() =>
                    {
                        if (JustText.Checked)
                        {
                            if (Parse(file.FullName, ParseText.Text))
                            {
                                FindFiles.Items.Add(file.FullName);
                                PopulateTreeView(TreeOfFiles, file.FullName, '\\');
                            }
                        }
                        else
                        {
                            FindFiles.Items.Add(file.FullName);
                            PopulateTreeView(TreeOfFiles, file.FullName, '\\');
                        }
                    }));
                }
                foreach (DirectoryInfo subdir in dir.GetDirectories())
                {
                    try
                    {
                        cancellationToken.ThrowIfCancellationRequested();
                        FindDirectory(subdir, pattern, cancellationToken);
                        Files.Invoke((Action)(() =>
                        {
                            foreach (FileInfo file in subdir.GetFiles())
                            {
                                Files.Items.Add(file.FullName);
                                CountFiles.Text = Files.Items.Count.ToString();
                                FileActive.Text = file.FullName;
                                //    Thread.Sleep(1);
                            }
                        }));
                    }
                    catch
                    {
                        //    Files.Invoke((MethodInvoker)(() =>
                        //    {
                        //    foreach (FileInfo file in subdir.GetFiles())
                        //    {
                        //        Files.Items.Add(file.FullName);
                        //             FileActive.Text = Files.Items.Count.ToString();
                        //         richTextBox1.Text = file.FullName;
                        //     }
                        //        MessageBox.Show(ex.Message.ToString());
                        //     }));
                    }
                }
            }
            catch (Exception)
            { }
        }
        #endregion

        #region TreeView
        /// <summary>
        /// Method for treeView
        /// </summary>
        /// <param name="treeView"></param>
        /// <param name="path"></param>
        /// <param name="pathSeparator"></param>       
        private void PopulateTreeView(TreeView treeView, string path, char pathSeparator)
        {
            TreeNode lastNode = null;
            treeView.PathSeparator = @"\";
            string subPathAgg;
            subPathAgg = string.Empty;
            foreach (string subPath in path.Split(pathSeparator))
            {
                subPathAgg += subPath + pathSeparator;
                TreeNode[] nodes = treeView.Nodes.Find(subPathAgg, true);
                if (nodes.Length == 0)
                    if (lastNode == null)
                        lastNode = treeView.Nodes.Add(subPathAgg, subPath);
                    else
                        lastNode = lastNode.Nodes.Add(subPathAgg, subPath);
                else
                    lastNode = nodes[0];
            }
        }
        #endregion

        #region Parse
        /// <summary>
        /// 
        /// </summary>
        /// <param name="path"></param>
        /// <param name="pattern"></param>
        /// <returns></returns>
        public bool Parse(string path, string pattern)
        {
         //    using (StreamReader sr = new StreamReader(path, UTF8Encoding.ASCII))
            using (StreamReader sr = new StreamReader(path, ASCIIEncoding.UTF8))   //just for english texts
            {
                Regex regex = new Regex(@"\w*" + pattern + @"\w*");
                MatchCollection matches = regex.Matches(sr.ReadToEnd());
                if (matches.Count > 0)
                {
                    return true;
                }
                else
                    return false;
            }
        }
        #endregion

        #region Start Searching
        /// <summary>
        /// Start searching and others threads 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Search_Click(object sender, EventArgs e)
        {
            try
            {
                if (cts != null)
                    cts.Cancel();
            }
            catch
            { }

            GC.Collect();
            Files.Items.Clear();
            i = 0;
            CountFiles.Text = "0";
            FindFiles.Items.Clear();
            Time.Text = "00:00:00";
            TreeOfFiles.Nodes.Clear();

            cts = new CancellationTokenSource();
            string seachDirectory = string.Empty;
            if (JustText.Checked)
                seachDirectory = "*" + FileName.Text + "*" + ".txt";
            else
                seachDirectory = "*" + FileName.Text + "*";
            var FindGo = Task.Run(() => FindDirectory(new DirectoryInfo(FileDir.Text), seachDirectory, cts.Token), cts.Token);
            var TimeGo = Task.Run(() =>
            {
                while (!FindGo.IsCompleted)
                {
                    Thread.Sleep(1000);
                    i++;
                    Time.Invoke((Action)(() => { Time.Text = TimeSpan.FromSeconds(i).ToString(@"hh\:mm\:ss"); }));
                }
            });
        }
        #endregion

        #region Close
        /// <summary>
        /// Closing and save parameteres of textboxes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Properties.Settings.Default.FileDir = FileDir.Text;
            Properties.Settings.Default.FileName = FileName.Text;
            Properties.Settings.Default.ParseText = ParseText.Text;
            Properties.Settings.Default.Save();
        }
        #endregion
    }
}
