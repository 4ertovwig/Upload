﻿namespace Search_Demo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MainTabControl = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.SearchFiles = new System.Windows.Forms.GroupBox();
            this.TreeOfFiles = new System.Windows.Forms.TreeView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.CountFiles = new System.Windows.Forms.Label();
            this.Time = new System.Windows.Forms.Label();
            this.FileActive = new System.Windows.Forms.RichTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.ParametersOfSearching = new System.Windows.Forms.GroupBox();
            this.JustText = new System.Windows.Forms.CheckBox();
            this.Folder = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.ParseText = new System.Windows.Forms.RichTextBox();
            this.FileDir = new System.Windows.Forms.TextBox();
            this.FileName = new System.Windows.Forms.TextBox();
            this.Stop = new System.Windows.Forms.Button();
            this.Search = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.FindFiles = new System.Windows.Forms.ListBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.Files = new System.Windows.Forms.ListBox();
            this.FoldDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.MainTabControl.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.SearchFiles.SuspendLayout();
            this.panel1.SuspendLayout();
            this.ParametersOfSearching.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainTabControl
            // 
            this.MainTabControl.Controls.Add(this.tabPage1);
            this.MainTabControl.Controls.Add(this.tabPage2);
            this.MainTabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.MainTabControl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.MainTabControl.Location = new System.Drawing.Point(0, 0);
            this.MainTabControl.Name = "MainTabControl";
            this.MainTabControl.SelectedIndex = 0;
            this.MainTabControl.Size = new System.Drawing.Size(604, 453);
            this.MainTabControl.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.SearchFiles);
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Controls.Add(this.ParametersOfSearching);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(596, 427);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // SearchFiles
            // 
            this.SearchFiles.Controls.Add(this.TreeOfFiles);
            this.SearchFiles.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.SearchFiles.Location = new System.Drawing.Point(6, 200);
            this.SearchFiles.Name = "SearchFiles";
            this.SearchFiles.Size = new System.Drawing.Size(587, 221);
            this.SearchFiles.TabIndex = 2;
            this.SearchFiles.TabStop = false;
            this.SearchFiles.Text = "Найденные Файлы:";
            // 
            // TreeOfFiles
            // 
            this.TreeOfFiles.Location = new System.Drawing.Point(8, 21);
            this.TreeOfFiles.Name = "TreeOfFiles";
            this.TreeOfFiles.Size = new System.Drawing.Size(572, 194);
            this.TreeOfFiles.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.CountFiles);
            this.panel1.Controls.Add(this.Time);
            this.panel1.Controls.Add(this.FileActive);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Location = new System.Drawing.Point(8, 122);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(578, 72);
            this.panel1.TabIndex = 1;
            // 
            // CountFiles
            // 
            this.CountFiles.AutoSize = true;
            this.CountFiles.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.CountFiles.Location = new System.Drawing.Point(177, 36);
            this.CountFiles.Name = "CountFiles";
            this.CountFiles.Size = new System.Drawing.Size(0, 16);
            this.CountFiles.TabIndex = 5;
            // 
            // Time
            // 
            this.Time.AutoSize = true;
            this.Time.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Time.Location = new System.Drawing.Point(139, 11);
            this.Time.Name = "Time";
            this.Time.Size = new System.Drawing.Size(56, 16);
            this.Time.TabIndex = 4;
            this.Time.Text = "00:00:00";
            // 
            // FileActive
            // 
            this.FileActive.Location = new System.Drawing.Point(265, 3);
            this.FileActive.Name = "FileActive";
            this.FileActive.Size = new System.Drawing.Size(310, 66);
            this.FileActive.TabIndex = 3;
            this.FileActive.Text = "";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(3, 36);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(161, 16);
            this.label6.TabIndex = 2;
            this.label6.Text = "Обработанных файлов:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(213, 11);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 16);
            this.label5.TabIndex = 1;
            this.label5.Text = "Файл:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(3, 11);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(130, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "Прошедшее время:";
            // 
            // ParametersOfSearching
            // 
            this.ParametersOfSearching.Controls.Add(this.JustText);
            this.ParametersOfSearching.Controls.Add(this.Folder);
            this.ParametersOfSearching.Controls.Add(this.label3);
            this.ParametersOfSearching.Controls.Add(this.label2);
            this.ParametersOfSearching.Controls.Add(this.label1);
            this.ParametersOfSearching.Controls.Add(this.ParseText);
            this.ParametersOfSearching.Controls.Add(this.FileDir);
            this.ParametersOfSearching.Controls.Add(this.FileName);
            this.ParametersOfSearching.Controls.Add(this.Stop);
            this.ParametersOfSearching.Controls.Add(this.Search);
            this.ParametersOfSearching.Location = new System.Drawing.Point(6, 6);
            this.ParametersOfSearching.Name = "ParametersOfSearching";
            this.ParametersOfSearching.Size = new System.Drawing.Size(580, 110);
            this.ParametersOfSearching.TabIndex = 0;
            this.ParametersOfSearching.TabStop = false;
            this.ParametersOfSearching.Text = "ПАРАМЕТРЫ ПОИСКА";
            // 
            // JustText
            // 
            this.JustText.AutoSize = true;
            this.JustText.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.JustText.Location = new System.Drawing.Point(150, 90);
            this.JustText.Name = "JustText";
            this.JustText.Size = new System.Drawing.Size(157, 17);
            this.JustText.TabIndex = 9;
            this.JustText.Text = "Только текстовые файлы";
            this.JustText.UseVisualStyleBackColor = true;
            // 
            // Folder
            // 
            this.Folder.Location = new System.Drawing.Point(254, 43);
            this.Folder.Name = "Folder";
            this.Folder.Size = new System.Drawing.Size(53, 25);
            this.Folder.TabIndex = 8;
            this.Folder.Text = "...";
            this.Folder.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(149, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "Слова для поиска";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(149, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "Директория";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(147, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 16);
            this.label1.TabIndex = 5;
            this.label1.Text = "Имя или часть имени";
            // 
            // ParseText
            // 
            this.ParseText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ParseText.Location = new System.Drawing.Point(313, 71);
            this.ParseText.Name = "ParseText";
            this.ParseText.Size = new System.Drawing.Size(241, 34);
            this.ParseText.TabIndex = 4;
            this.ParseText.Text = "";
            // 
            // FileDir
            // 
            this.FileDir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FileDir.Location = new System.Drawing.Point(313, 45);
            this.FileDir.Name = "FileDir";
            this.FileDir.Size = new System.Drawing.Size(241, 22);
            this.FileDir.TabIndex = 3;
            // 
            // FileName
            // 
            this.FileName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FileName.Location = new System.Drawing.Point(313, 18);
            this.FileName.Name = "FileName";
            this.FileName.Size = new System.Drawing.Size(239, 22);
            this.FileName.TabIndex = 2;
            // 
            // Stop
            // 
            this.Stop.Location = new System.Drawing.Point(26, 66);
            this.Stop.Name = "Stop";
            this.Stop.Size = new System.Drawing.Size(101, 37);
            this.Stop.TabIndex = 1;
            this.Stop.Text = "Stop";
            this.Stop.UseVisualStyleBackColor = true;
            // 
            // Search
            // 
            this.Search.Location = new System.Drawing.Point(26, 19);
            this.Search.Name = "Search";
            this.Search.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Search.Size = new System.Drawing.Size(100, 37);
            this.Search.TabIndex = 0;
            this.Search.Text = "Go";
            this.Search.UseVisualStyleBackColor = true;
            this.Search.Click += new System.EventHandler(this.Search_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(596, 427);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.FindFiles);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox4.Location = new System.Drawing.Point(413, 6);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(177, 413);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Найденные файлы:";
            // 
            // FindFiles
            // 
            this.FindFiles.FormattingEnabled = true;
            this.FindFiles.HorizontalScrollbar = true;
            this.FindFiles.ItemHeight = 16;
            this.FindFiles.Location = new System.Drawing.Point(6, 21);
            this.FindFiles.Name = "FindFiles";
            this.FindFiles.Size = new System.Drawing.Size(165, 388);
            this.FindFiles.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.Files);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox3.Location = new System.Drawing.Point(6, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(401, 413);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Просмотренные файлы:";
            // 
            // Files
            // 
            this.Files.FormattingEnabled = true;
            this.Files.HorizontalScrollbar = true;
            this.Files.ItemHeight = 16;
            this.Files.Location = new System.Drawing.Point(6, 21);
            this.Files.Name = "Files";
            this.Files.Size = new System.Drawing.Size(389, 388);
            this.Files.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(604, 453);
            this.Controls.Add(this.MainTabControl);
            this.Name = "Form1";
            this.Text = "File Searching";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.MainTabControl.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.SearchFiles.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ParametersOfSearching.ResumeLayout(false);
            this.ParametersOfSearching.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl MainTabControl;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox ParametersOfSearching;
        private System.Windows.Forms.Button Stop;
        private System.Windows.Forms.Button Search;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.RichTextBox ParseText;
        private System.Windows.Forms.TextBox FileDir;
        private System.Windows.Forms.TextBox FileName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Folder;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox JustText;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox SearchFiles;
        private System.Windows.Forms.TreeView TreeOfFiles;
        private System.Windows.Forms.Label CountFiles;
        private System.Windows.Forms.Label Time;
        private System.Windows.Forms.RichTextBox FileActive;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ListBox FindFiles;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ListBox Files;
        private System.Windows.Forms.FolderBrowserDialog FoldDialog;


    }
}

